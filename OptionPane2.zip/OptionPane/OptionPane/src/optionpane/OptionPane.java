/*
 * GPA CALC
 * AAINGEL L.
 */
package optionpane;
import java.io.FileNotFoundException;
import javax.swing.*;
import javax.swing.JOptionPane;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author LOCKRIDA7610
 */
public class OptionPane {


    public static void main(String[] args) {
        
    try {

        UIManager.setLookAndFeel(
            UIManager.getSystemLookAndFeelClassName());
    } 
    catch (UnsupportedLookAndFeelException e) {
  System.out.println("error");
       // handle exception
    }
    catch (ClassNotFoundException e) {
  System.out.println("error");
       // handle exception
    }
    catch (InstantiationException e) {
  System.out.println("error");
       // handle exception
    }
    catch (IllegalAccessException e) {
  System.out.println("error");
    }
            String name;
            double c1;
            String c1n;
            int x = 1;
            int pos = 0;
            int maxPos;
            String dispHours = " ";
            String dispLetters = " ";
            String finalDisp = "";



            //JOPTIONPANE READS AS STRING BE DEFAULT, NUMBERS WILL HAVE TO BE     ->      Double.parseDouble()'d

            JOptionPane.showMessageDialog(null, "GPAcalc v0.2\nPRESS [X] ON NEXT BOX TO EXIT");

            //get name from showinputdialog(method
            name = JOptionPane.showInputDialog("what is your name?");
            finalDisp = name + '\n';
            if (name == null) {
                System.exit(1);
            }

            //  making arraylist(s)
            maxPos = Integer.parseInt(JOptionPane.showInputDialog("how many classes?"));
            //////////////////////////
            List < String > letterGrades = new ArrayList(maxPos);
            List < String > classHours = new ArrayList(maxPos);
            ///////////////////////////////////////////////////////////////////////////////////////////////////



            /*
       
       
       //get CLASS names WITH LOOP
    try{
       c1 = Double.parseDouble(JOptionPane.showInputDialog(null, "Letter grade of class " + pos));
    } catch(NumberFormatException e){
   JOptionPane.showMessageDialog(null, "ERROR: ENTER AN INTEGER ONLY!\n OK to reset");
   continue;
    }
if (c1 == -1){System.exit(1);}    
      */
            for (int i = 0; i < maxPos; i++) {
                String addValue = (JOptionPane.showInputDialog(null, "Credit Hours of class " + i));

                   
                if (addValue == null) {
                    System.exit(1);
                }
                   classHours.add(addValue);
                        //CONVERT TO INT LATER FOR CALCS, DID NOT DO HERE                   
            }
            
            
            ///
            
            for (int i = 0; i < maxPos; i++) {
                String addValue = (JOptionPane.showInputDialog(null, "Letter Grade of class " + i));

                if (addValue == null) {
                    System.exit(1);
                }
                   letterGrades.add(addValue);  
            }
            ///
            
          for (int i=0; i < letterGrades.size(); i++){

        dispLetters = letterGrades.toString().replace(',', '\n');
          }
          
          //
          List < String > holdGPA = new ArrayList(maxPos);
          
          for (int i=0; i < classHours.size(); i++){
          dispLetters = letterGrades.toString().replace('A', '4'); 
          dispLetters = letterGrades.toString().replace('B', '3'); 
          dispLetters = letterGrades.toString().replace('C', '2'); 
          dispLetters = letterGrades.toString().replace('D', '1'); 
          dispLetters = letterGrades.toString().replace('E', '0');
          dispLetters = letterGrades.toString().replace('W', '0');
          dispLetters = letterGrades.toString().replace('I', '9');
          //PUT VARIABLES DISPLETTERS AND HOURS INTO VARIABLES AND PUT IN BELOW STATEMENT INSTEAD OF .GET CHUNKS.
          finalDisp = finalDisp + "CR. HRS: " + classHours.get(i) + ", GRADE: " + letterGrades.get(i) + '\n';
                 } 
          System.out.println(letterGrades);
          System.out.println(classHours);   
          
          JOptionPane.showMessageDialog(null, finalDisp);
 
         PrintWriter outputText;
        try {
            outputText = new PrintWriter(name + "s_grades" + ".txt");
            outputText.println(finalDisp);
            outputText.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(OptionPane.class.getName()).log(Level.SEVERE, null, ex);
        }


//w = withdrawl
//i = incomplete
    
        
    }
    //---
         

}