﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
/**
* 4/29
* CSC 153
* Aaingel L.
* Random number file writer
*/
namespace FileWriterGUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void GenerateButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.InitialDirectory = "C:/";
            saveFile.Title = "Save the output";
            saveFile.CheckPathExists = true;
            saveFile.DefaultExt = "txt";
            saveFile.Filter = "TEXT files (*.txt)|*.txt";
            saveFile.FilterIndex = 2;
            saveFile.RestoreDirectory = true;
            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                string fileLoc = saveFile.FileName;
                string listLen = howMany.Text;
                Console.WriteLine(listLen);
                Random rand = new Random();
                int min = 1;
                int max = 100;
                int randnum = 1;
                for (int i = 1; i < Int32.Parse(howMany.Text) + 1; i++)
                {
                    randnum = rand.Next(min, max);
                    StreamWriter fileFile;
                    fileFile = File.AppendText(fileLoc);//fixed

                    fileFile.WriteLine(randnum);
                    fileFile.Close();
                }
            }

            
        }
    }
}
