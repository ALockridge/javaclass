﻿
namespace FileWriterGUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.generateButton = new System.Windows.Forms.Button();
            this.howMany = new System.Windows.Forms.TextBox();
            this.howManyLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // generateButton
            // 
            this.generateButton.Location = new System.Drawing.Point(13, 91);
            this.generateButton.Name = "generateButton";
            this.generateButton.Size = new System.Drawing.Size(205, 41);
            this.generateButton.TabIndex = 0;
            this.generateButton.Text = "GENERATE";
            this.generateButton.UseVisualStyleBackColor = true;
            this.generateButton.Click += new System.EventHandler(this.GenerateButton_Click);
            // 
            // howMany
            // 
            this.howMany.Location = new System.Drawing.Point(13, 55);
            this.howMany.Name = "howMany";
            this.howMany.Size = new System.Drawing.Size(205, 20);
            this.howMany.TabIndex = 1;
            // 
            // howManyLabel
            // 
            this.howManyLabel.AutoSize = true;
            this.howManyLabel.Location = new System.Drawing.Point(12, 39);
            this.howManyLabel.Name = "howManyLabel";
            this.howManyLabel.Size = new System.Drawing.Size(132, 13);
            this.howManyLabel.TabIndex = 2;
            this.howManyLabel.Text = "How many #s to generate:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(230, 403);
            this.Controls.Add(this.howManyLabel);
            this.Controls.Add(this.howMany);
            this.Controls.Add(this.generateButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button generateButton;
        private System.Windows.Forms.TextBox howMany;
        private System.Windows.Forms.Label howManyLabel;
    }
}

