/*
 * GPA CALC
 * AAINGEL L.
 */
package optionpane;
import javax.swing.*;
import javax.swing.JOptionPane;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author LOCKRIDA7610
 */
public class OptionPane {


    public static void main(String[] args) {
        int quit = 0;
        while (quit == 0) {
            String name;
            double c1;
            String c1n;
            int x = 1;
            int pos = 0;
            int maxPos;
            String dispNames = " ";
            String dispLetters = " ";



            //JOPTIONPANE READS AS STRING BE DEFAULT, NUMBERS WILL HAVE TO BE     ->      Double.parseDouble()'d

            JOptionPane.showMessageDialog(null, "GPAcalc v0.2\nPRESS [X] ON NEXT BOX TO EXIT");

            //get name from showinputdialog(method
            name = JOptionPane.showInputDialog("what is your name?");
            if (name == null) {
                System.exit(1);
            }

            //  making arraylist(s)
            maxPos = Integer.parseInt(JOptionPane.showInputDialog("how many classes?"));
            //////////////////////////
            List < String > letterGrades = new ArrayList(maxPos);
            List < String > classNames = new ArrayList(maxPos);
            ///////////////////////////////////////////////////////////////////////////////////////////////////



            /*
       
       
       //get CLASS names WITH LOOP
    try{
       c1 = Double.parseDouble(JOptionPane.showInputDialog(null, "Letter grade of class " + pos));
    } catch(NumberFormatException e){
   JOptionPane.showMessageDialog(null, "ERROR: ENTER AN INTEGER ONLY!\n OK to reset");
   continue;
    }
if (c1 == -1){System.exit(1);}    
      */
            for (int i = 0; i < maxPos; i++) {
                String addValue = (JOptionPane.showInputDialog(null, "name of class " + i));

                   classNames.add(addValue);  
            }
            
            ///
            
            for (int i = 0; i < maxPos; i++) {
                String addValue = (JOptionPane.showInputDialog(null, "letter grade of class " + i));

                   letterGrades.add(addValue);  
            }
            ///
            
          for (int i=0; i < letterGrades.size(); i++){

        dispLetters = letterGrades.toString().replace(',', '\n');
          }
          
          //
          
          for (int i=0; i < classNames.size(); i++){
             
        dispNames = classNames.toString().replace(',', '\n');
          
                 }
         JOptionPane.showMessageDialog(null, dispNames + "\n" + dispLetters);        
        }
        
    }
    //---
    }