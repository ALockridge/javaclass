/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package optionpane;

import javax.swing.JOptionPane;
/**
 *
 * @author LOCKRIDA7610
 */
public class OptionPane {

    
    public static void main(String[] args) {
        int quit = 0;
        while (quit == 0){
        
        String name;
        int c1 = -1;
        String c1n;
        int c2 = -1;
        String c2n;
        int c3 = -1;
        String c3n;
       //JOPTIONPANE READS AS STRING BE DEFAULT, NUMBERS WILL HAVE TO BE     ->      Integer.parseInt()'d
       
            JOptionPane.showMessageDialog(null, "GPAcalc v0.2");
            
                   //get name from showinputdialog(method
       name = JOptionPane.showInputDialog("What is your name?");
if (name == null){System.exit(1);}
       ///////////////////////////////////////////////////////////////////////////////////////////////////
       //get class1 name
       c1n = JOptionPane.showInputDialog(null, "Name of class1:");
if (c1n == null){System.exit(1);}
       //get class1 grade
    try{
        
       c1 = Integer.parseInt(JOptionPane.showInputDialog(null, "Number grade of class1:"));
    } catch(NumberFormatException e){
   JOptionPane.showMessageDialog(null, "ERROR: ENTER AN INTEGER ONLY!\n OK to reset");
   continue;
    }
if (c1 == -1){System.exit(1);}    
       //get class2 name
       c2n = JOptionPane.showInputDialog(null, "Name of class2:");
if (c2n == null){System.exit(1);}       
       //get class2 grade
    try{
        
       c2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Number grade of class2:"));
    } catch(NumberFormatException e){
   JOptionPane.showMessageDialog(null, "ERROR: ENTER AN INTEGER ONLY!\n OK to reset");
   continue;
    }
if (c2 == -1){System.exit(1);}       
      //get class3 name

      c3n = JOptionPane.showInputDialog(null, "Name of class3:");
if (c3n == null){System.exit(1);}       
       //get class3 grade

       try{
        
       c3 = Integer.parseInt(JOptionPane.showInputDialog(null, "Number grade of class3:"));
    } catch(NumberFormatException e){
   JOptionPane.showMessageDialog(null, "ERROR: ENTER AN INTEGER ONLY!\n OK to reset");
   continue;
    }
if (c3 == -1){System.exit(1);}

       JOptionPane.showMessageDialog(null, name + "\n======================\n" 
               + c1n + ": " + c1 
               + "\n" + c2n + ": " + c2
               + "\n" + c3n + ": " + c3);
        }
        
    }
    
}
