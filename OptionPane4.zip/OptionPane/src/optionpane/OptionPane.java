// GPA CALC, AAINGEL L.
package optionpane;
import java.io.FileNotFoundException;
import javax.swing.*;
import javax.swing.JOptionPane;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
* @author LOCKRIDA7610
**/
public class OptionPane {
  public static void main(String[] args) {
    try {
      UIManager.setLookAndFeel(
        UIManager.getSystemLookAndFeelClassName());
    } catch (UnsupportedLookAndFeelException | ClassNotFoundException | InstantiationException | IllegalAccessException e) {
      System.out.println("error");
      // handle exception
    }
    int maxPos;
    String intro = "<html><pre>";
    String end = "</pre></html>";
    String br = "<br>";
    ///declare empty strings
    String dispHours = " ";
    String dispLetters = " ";
    String finalDisp;
    JOptionPane.showMessageDialog(null, intro + "GPACalc v1.0" + br + "by Aaingel L. "+ end);
    //get name from showinputdialog(method
    String name = JOptionPane.showInputDialog("what is your name? (leave empty to exit)");
    if (name.length() < 1) {
      System.exit(1);
    }
        finalDisp = intro + name + '\n';
    //  making arraylist(s)
    maxPos = Integer.parseInt(JOptionPane.showInputDialog("how many classes?"));
    List < String > letterGrades = new ArrayList(maxPos);
    List < String > classHours = new ArrayList(maxPos); 
    for (int i = 0; i < maxPos; i++) {
      String addValue = (JOptionPane.showInputDialog(null, intro + "Credit Hours of class " + (i + 1) + end));
  if (addValue == null || addValue.length() > 1 || isNumber(addValue) == false) {
        JOptionPane.showMessageDialog(null, "INPUT ERROR! MUST BE A SINGLE DIGIT NUMBER!");
        System.exit(1);
      }
  classHours.add(addValue);
    }
    for (int i = 0; i < maxPos; i++) {
      String addValue = (JOptionPane.showInputDialog(null, intro + "Letter Grade of class " + (i + 1)) + end).toLowerCase();

      if (addValue == null || addValue.length() > 1) {
        JOptionPane.showMessageDialog(null, "INPUT ERROR! MUST BE A, B, C, D, F, W, OR I!");
        System.exit(1);
      }
      letterGrades.add(addValue);
    }
    for (int i = 0; i < classHours.size(); i++) {
      letterGrades.set(i, letterGrades.get(i).replace('a', '4'));
      letterGrades.set(i, letterGrades.get(i).replace('b', '3'));
      letterGrades.set(i, letterGrades.get(i).replace('c', '2'));
      letterGrades.set(i, letterGrades.get(i).replace('d', '1'));
      letterGrades.set(i, letterGrades.get(i).replace('f', '0'));
      letterGrades.set(i, letterGrades.get(i).replace("w", "WITHDRAWN"));
      letterGrades.set(i, letterGrades.get(i).replace("i", "INCOMPLETE"));  

      //PUT VARIABLES DISPLETTERS AND HOURS INTO VARIABLES AND PUT IN BELOW STATEMENT INSTEAD OF .GET CHUNKS.
      finalDisp = finalDisp + intro +
        "CR. HRS: " + classHours.get(i) + ", PTS: " + letterGrades.get(i) + '\n';
    }
    //GATHER SUMS OF HOURS AND GRADES RESPECTIVELY          
    int hourSum = 0;
    for (int i = 0; i < classHours.size(); i++) {
      hourSum += Integer.parseInt(classHours.get(i));
    }
    int gradeSum = 0;
    for (int i = 0; i < letterGrades.size(); i++) {
      gradeSum += Integer.parseInt(letterGrades.get(i).replaceAll(end, ""));
    }
    //PRINT TO CONSOLE FOR DEBUGGING PURPOSES
    System.out.println(hourSum);
    System.out.println(gradeSum);
    //CALC GPA
    double finalGPA = ((gradeSum * hourSum) / hourSum) / classHours.size();
    //FILE SAVE NOTIFICATION
    JOptionPane.showMessageDialog(null, finalDisp + "\nG.P.A. : " + finalGPA + "\n\n[OK] to save to file & exit");
    //WRITE TO TXT FILE WITH NAME AND DATA, AFTER REPLACING HTMLTAGS WITH BLANK, AND/OR \N FOR BREAKS
    PrintWriter outputText;
    try {
      outputText = new PrintWriter(name + "s_grades" + ".txt");
      finalDisp = finalDisp.replaceAll(intro, "");
      finalDisp = finalDisp.replaceAll(br, "\n");
      finalDisp = finalDisp.replaceAll(end, "");
      outputText.println(finalDisp + "\nG.P.A. : " + finalGPA);
      outputText.close();
    } catch (FileNotFoundException ex) {
      Logger.getLogger(OptionPane.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
      JOptionPane.showMessageDialog(null, finalDisp + "written to " + name + "s_grades" + ".txt");
    }
  }
  //adapted code
  public static boolean isNumber(String stringN) {
    if (stringN == null) {
        return false;
    }
    try {
        int d = Integer.parseInt(stringN);
    } catch (NumberFormatException nfe) {
        return false;
    }
    return true;
}
}