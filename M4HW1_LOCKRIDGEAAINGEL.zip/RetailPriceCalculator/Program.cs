﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 5/4/22
* CSC 153
* Aaingel Lockridge
* retail price calc
*/
namespace RetailPriceCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter item's wholesale cost: ");
            double wholesale = Double.Parse(Console.ReadLine());
            Console.WriteLine("Enter markup percentage: ");
            double markup = Double.Parse(Console.ReadLine());
            double answer = CalculateRetail(wholesale, markup);
            Console.WriteLine(answer);
            Console.ReadLine();
        }
        //this is probably bad practice
        public static double CalculateRetail(double wholesale, double markup)
        {
            double answer = wholesale + wholesale * markup;
            return answer;
        }
    }
}